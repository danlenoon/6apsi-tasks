// Module 4 - Activity 3 - A RESTful API (in-memory)
//
// Turn the server into a full CRUD REST API for sightings. The data lives in a
// plain array for now, so it resets whenever the server restarts - that is on
// purpose. Module 5 moves this exact API onto a real PostgreSQL database.
//
// Build all five routes inside createApp() and RETURN the app. Read
// backend-theory/05 (RESTful design patterns) carefully - it defines which verb,
// which URL, and which status code each operation uses.

import express from 'express'

export function createApp() {
  const app = express()
  app.use(express.json())

  // In-memory store, fresh for each createApp(). `nextId` hands out new ids.
  const sightings = [
    { id: 1, place: 'Library 3rd floor', description: 'cold spot near the stacks', spookiness: 4, reportedAt: '2026-07-01T20:00:00Z' },
    { id: 2, place: 'Old gym', description: 'footsteps, nobody there', spookiness: 5, reportedAt: '2026-07-03T22:15:00Z' },
  ]
  let nextId = 3

  // Helper you may use: is this a valid new sighting body?
  // (place must be a non-empty string; spookiness must be an integer 1..5)

  app.get('/sightings', (req, res) => {
    res.status(200).json(sightings)
  })

  app.get('/sightings/:id', (req, res) => {
    const sighting = sightings.find(s => s.id === parseInt(req.params.id, 10))
    if (!sighting) {
      return res.status(404).json({ error: 'Not found' })
    }
    res.status(200).json(sighting)
  })

  app.post('/sightings', (req, res) => {
    const { place, description, spookiness } = req.body

    if (typeof place !== 'string' || place.trim() === '') {
      return res.status(400).json({ error: 'Place must be a non-empty string.' })
    }

    if (!Number.isInteger(spookiness) || spookiness < 1 || spookiness > 5) {
      return res.status(400).json({ error: 'Spookiness must be an integer between 1 and 5.' })
    }

    const newSighting = {
      id: nextId++,
      place,
      description,
      spookiness,
      reportedAt: new Date().toISOString()
    }
    sightings.push(newSighting)
    res.status(201).json(newSighting)
  })

  app.patch('/sightings/:id', (req, res) => {
    const sighting = sightings.find(s => s.id === parseInt(req.params.id, 10))
    if (!sighting) {
      return res.status(404).json({ error: 'Not found' })
    }

    const { place, description, spookiness } = req.body
    if (place !== undefined) sighting.place = place
    if (description !== undefined) sighting.description = description
    if (spookiness !== undefined) sighting.spookiness = spookiness

    res.status(200).json(sighting)
  })

  app.delete('/sightings/:id', (req, res) => {
    const index = sightings.findIndex(s => s.id === parseInt(req.params.id, 10))
    if (index === -1) {
      return res.status(404).json({ error: 'Not found' })
    }
    sightings.splice(index, 1)
    res.status(204).end()
  })

  // 404 fallback for anything unmatched.
  app.use((req, res) => res.status(404).json({ error: 'Not found' }))

  return app
}
