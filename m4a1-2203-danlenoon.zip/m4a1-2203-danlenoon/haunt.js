// Module 4 - Activity 1 - Node basics: the HAUnted Sightings core module
//
// This is the pure logic at the heart of the HAUnted Sightings app. No server
// yet - just functions you can import and test. You will import these same
// helpers from your Express routes in later activities.
//
// Implement and EXPORT each function below. Research the concept named in each
// TODO; do not just copy an answer. Read backend-theory/02 for import/export.

// TODO: export a function `slugify(place)` that turns a place name into a URL-safe
// slug: lowercase, trim, and replace every run of non-alphanumeric characters
// with a single hyphen (no leading or trailing hyphen).
//   slugify('Old Gym')               -> 'old-gym'
//   slugify('  Library, 3rd Floor! ')-> 'library-3rd-floor'
// Hint: a regular expression with String.prototype.replace does this in two steps.

// TODO: export a function `spookinessLabel(level)` that maps a spookiness level
// (1..5) to a label, and returns 'Unknown' for anything else.
//   1 -> 'Barely a chill'   2 -> 'Goosebumps'   3 -> 'Spooky'
//   4 -> 'Terrifying'       5 -> 'Run!'

// TODO: export a function `isRecent(reportedAt, now = Date.now())` that returns
// true when `reportedAt` (an ISO date string) is within the last 7 days of `now`
// (and not in the future). Hint: new Date(...).getTime() and compare milliseconds.

// TODO: export a function `validateSighting(sighting)` that returns
// `{ valid, errors }` where `errors` is an array of strings:
//   - `place` must be a non-empty string
//   - `spookiness` must be an integer from 1 to 5
//   - `description`, if present, must be a string
// `valid` is true only when `errors` is empty.
export function slugify(place) {
  return place.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

export function spookinessLabel(level) {
  switch (level) {
    case 1:
      return 'Barely a chill';
    case 2:
      return 'Goosebumps';
    case 3:
      return 'Spooky';
    case 4:
      return 'Terrifying';
    case 5:
      return 'Run!';
    default:
      return 'Unknown';
  }
}

export function isRecent(reportedAt, now = Date.now()) {
  const reportedTime = new Date(reportedAt).getTime();
  const nowTime = typeof now === 'number' ? now : new Date(now).getTime();
  const diff = nowTime - reportedTime;
  const sevenDaysMs = 7 * 24 * 60 * 60 * 1000;
  return diff >= 0 && diff <= sevenDaysMs;
}

export function validateSighting(sighting) {
  const errors = [];

  if (!sighting || typeof sighting !== 'object') {
    return { valid: false, errors: ['Sighting must be an object'] };
  }

  if (typeof sighting.place !== 'string' || sighting.place.trim() === '') {
    errors.push('Place must be a non-empty string');
  }

  if (
    typeof sighting.spookiness !== 'number' || !Number.isInteger(sighting.spookiness) || sighting.spookiness < 1 || sighting.spookiness > 5
  ) {
    errors.push('Spookiness must be an integer between 1 and 5');
  }

  if (
    sighting.description !== undefined && sighting.description !== null && typeof sighting.description !== 'string'
  ) {
    errors.push('Description must be a string');
  }

  return {
    valid: errors.length === 0, errors
  };
}