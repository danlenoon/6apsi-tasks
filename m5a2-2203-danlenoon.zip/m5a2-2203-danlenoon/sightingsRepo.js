// Module 5 - Activity 2 - PostgreSQL CRUD (the data-access layer)
//
// This is the full data-access layer for HAUnted Sightings: every database
// operation the app needs, as one focused module. In the capstone (m5a3) your
// Express routes will call these functions - the routes handle HTTP, this module
// handles SQL, and the two never mix.
//
// GOLDEN RULE (graded): every value goes in as a PARAMETER ($1, $2, ...), never
// by string concatenation. Read db-theory/04 for the full CRUD-in-SQL pattern.

export async function createSchema(pool) {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS sightings (
      id SERIAL PRIMARY KEY,
      place TEXT NOT NULL,
      description TEXT,
      spookiness INTEGER NOT NULL,
      reported_at TIMESTAMPTZ DEFAULT now()
    )
  `);
}

export async function create(pool, { place, description, spookiness }) {
  const result = await pool.query(
    'INSERT INTO sightings (place, description, spookiness) VALUES ($1, $2, $3) RETURNING *',
    [place, description, spookiness]
  );
  return result.rows[0];
}

export async function getAll(pool) {
  const result = await pool.query('SELECT * FROM sightings ORDER BY id');
  return result.rows;
}

export async function getById(pool, id) {
  const result = await pool.query('SELECT * FROM sightings WHERE id = $1', [id]);
  return result.rows[0] || null;
}

export async function update(pool, id, { place, description, spookiness }) {
  const result = await pool.query(
    'UPDATE sightings SET place = $1, description = $2, spookiness = $3 WHERE id = $4 RETURNING *',
    [place, description, spookiness, id]
  );
  return result.rows[0] || null;
}

export async function remove(pool, id) {
  const result = await pool.query('DELETE FROM sightings WHERE id = $1 RETURNING id', [id]);
  return result.rowCount > 0;
}
