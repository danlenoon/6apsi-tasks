// Module 5 - Activity 3 - REST API backed by PostgreSQL (the capstone)
//
// This is where the whole midterm comes together. You have a REST API (Module 4)
// and a Postgres data layer (m5a2). Now you WIRE them: build the Express routes so
// that each one calls the matching data-access function. The routes handle HTTP
// (status codes, req/res); the data layer (sightingsRepo.js, provided) handles
// SQL. Keep that separation clean - it is the point of this activity.
//
// Build createApp(pool) and RETURN the app. Every route is async and awaits the
// repo. Read db-theory/04 for the route -> data-access mapping.

import express from 'express'
import { getAll, getById, create, update, remove } from './sightingsRepo.js'

function validNew(body) {
  return (
    typeof body?.place === 'string' &&
    body.place.trim() !== '' &&
    Number.isInteger(body?.spookiness) &&
    body.spookiness >= 1 &&
    body.spookiness <= 5
  )
}

export function createApp(pool) {
  const app = express()
  app.use(express.json())

  app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok' })
  })

  app.get('/sightings', async (req, res) => {
    const rows = await getAll(pool)
    res.status(200).json(rows)
  })

  app.get('/sightings/:id', async (req, res) => {
    const row = await getById(pool, req.params.id)
    if (!row) {
      return res.status(404).json({ error: 'Not found' })
    }
    res.status(200).json(row)
  })

  app.post('/sightings', async (req, res) => {
    if (!validNew(req.body)) {
      return res.status(400).json({ error: 'Invalid input' })
    }
    const created = await create(pool, req.body)
    res.status(201).json(created)
  })

  app.patch('/sightings/:id', async (req, res) => {
    const existing = await getById(pool, req.params.id)
    if (!existing) {
      return res.status(404).json({ error: 'Not found' })
    }
    const merged = { ...existing, ...req.body }
    const updated = await update(pool, req.params.id, merged)
    res.status(200).json(updated)
  })

  app.delete('/sightings/:id', async (req, res) => {
    const removed = await remove(pool, req.params.id)
    if (removed) {
      res.status(204).end()
    } else {
      res.status(404).json({ error: 'Not found' })
    }
  })

  app.use((req, res) => res.status(404).json({ error: 'Not found' }))
  
  return app
}
