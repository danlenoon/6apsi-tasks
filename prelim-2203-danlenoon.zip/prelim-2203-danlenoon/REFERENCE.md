# Reference sheet (allowed during the exam)

You may use this sheet. The examples here use **different** values than the exam
tasks, so they show you the *shape* of each tool without handing you the answer.
This is the only reference you may use - no other docs, no internet, no AI.

## Template literals

```js
const name = 'Sam'
`Welcome, ${name}.`        // 'Welcome, Sam.'
```

## Ternary (one-line if/else that produces a value)

```js
const label = score >= 50 ? 'pass' : 'fail'
```

## Modulo (remainder)

```js
17 % 5       // 2
n % 2 === 0  // true when n is even
```

## String methods

```js
'hello'.toUpperCase()     // 'HELLO'
'hello'.charAt(0)         // 'h'   (same as 'hello'[0])
'hello'.slice(1)          // 'ello'  (everything from index 1 on)
'hello'.toLowerCase()     // 'hello'
'abc'.includes('b')       // true
```

Counting with a loop:

```js
let count = 0
for (const ch of 'banana') {
  if (ch === 'a') count++
}
count                     // 3
```

## Arrays: map, filter, reduce

```js
const n = [1, 2, 3, 4]

n.map(x => x + 10)                 // [11, 12, 13, 14]   transform each item
n.filter(x => x > 2)               // [3, 4]             keep some items
n.reduce((acc, x) => acc * x, 1)   // 24                 fold into one value (here: multiply)

const users = [{ age: 30 }, { age: 25 }]
users.map(u => u.age)              // [30, 25]           map objects to one property
```

## Objects: destructuring and spread

```js
const point = { x: 1, y: 2 }
const { x, y } = point             // x is 1, y is 2

const updated = { ...point, y: 9 } // { x: 1, y: 9 }   new object, point unchanged
```

## Functions: arrow functions and closures

```js
const triple = n => n * 3          // arrow function
triple(4)                          // 12

function makeAdder(step) {         // a closure: remembers `step`
  return function (n) {
    return n + step
  }
}
const addTen = makeAdder(10)
addTen(5)                          // 15
```

## React: a function component with a prop

```jsx
export default function Welcome({ title }) {
  return <h2>Welcome to {title}</h2>
}
// <Welcome title="React" />  renders  <h2>Welcome to React</h2>
```
