import { describe, it, expect } from 'vitest'
import { double, evens, names, total } from '../src/arrays.js'

// Tier 2 (map/filter) rising to Tier 3 (reduce). map/filter should be within
// reach; total() with reduce is a stretch item.
describe('3. Arrays', () => {
  it('double() maps each number to its double', () => {
    expect(double([1, 2, 3])).toEqual([2, 4, 6])
    expect(double([])).toEqual([])
  })

  it('evens() filters out the odd numbers', () => {
    expect(evens([1, 2, 3, 4])).toEqual([2, 4])
    expect(evens([1, 3, 5])).toEqual([])
  })

  it('names() maps an array of people to their names', () => {
    expect(names([{ name: 'Ana' }, { name: 'Ben' }])).toEqual(['Ana', 'Ben'])
    expect(names([])).toEqual([])
  })

  // Stretch: reduce.
  it('total() reduces the array to its sum', () => {
    expect(total([1, 2, 3])).toBe(6)
    expect(total([])).toBe(0)
  })
})
