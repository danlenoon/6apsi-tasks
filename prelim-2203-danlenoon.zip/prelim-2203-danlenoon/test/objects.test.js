import { describe, it, expect } from 'vitest'
import { fullName, withUpdates } from '../src/objects.js'

describe('4. Objects', () => {
  it('fullName() destructures first and last name', () => {
    expect(fullName({ firstName: 'Juan', lastName: 'Cruz' })).toBe('Juan Cruz')
    expect(fullName({ firstName: 'Ana', lastName: 'Reyes' })).toBe('Ana Reyes')
  })

  // Stretch: spread, and the original must not be mutated.
  it('withUpdates() merges with spread without mutating the original', () => {
    const original = { a: 1, b: 2 }
    expect(withUpdates(original, { b: 9 })).toEqual({ a: 1, b: 9 })
    expect(original).toEqual({ a: 1, b: 2 }) // unchanged
  })
})
