import { describe, it, expect } from 'vitest'
import { firstLetter, shout, capitalize, countVowels } from '../src/strings.js'

// Tier 1-2 - string basics, ending on a slightly harder count.
describe('2. Strings', () => {
  it('firstLetter() returns the first character', () => {
    expect(firstLetter('hello')).toBe('h')
    expect(firstLetter('Ana')).toBe('A')
  })

  it('shout() upper-cases the whole string and adds "!"', () => {
    expect(shout('hi')).toBe('HI!')
    expect(shout('go')).toBe('GO!')
  })

  it('capitalize() upper-cases only the first letter', () => {
    expect(capitalize('hello')).toBe('Hello')
    expect(capitalize('world')).toBe('World')
  })

  // Stretch: counting requires a loop or filter over the characters.
  it('countVowels() counts vowels case-insensitively', () => {
    expect(countVowels('hello')).toBe(2)
    expect(countVowels('AEIOU')).toBe(5)
  })
})
