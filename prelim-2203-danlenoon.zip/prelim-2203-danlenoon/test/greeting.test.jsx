import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import Greeting from '../src/Greeting.jsx'

// The "little React" portion: one small function component that takes a prop
// and renders it. This is the bridge from Module 1 (functions + template
// literals) to Module 2 (components + JSX).
describe('6. React - Greeting component', () => {
  it('renders a level-1 heading that greets the name prop', () => {
    render(<Greeting name="Ana" />)
    expect(screen.getByRole('heading', { level: 1 })).toHaveTextContent('Hello, Ana!')
  })

  it('greets a different name from the prop (props are just data)', () => {
    render(<Greeting name="Juan" />)
    expect(screen.getByRole('heading', { level: 1 })).toHaveTextContent('Hello, Juan!')
  })
})
