import { describe, it, expect } from 'vitest'
import { greet, square, isEven, parityLabel } from '../src/basics.js'

// Tier 1 - warm-ups. Everyone should be able to land these.
describe('1. Basics', () => {
  it('greet() builds a greeting with a template literal', () => {
    expect(greet('Juan')).toBe('Hello, Juan!')
    expect(greet('Ana')).toBe('Hello, Ana!')
  })

  it('square() returns a number times itself', () => {
    expect(square(5)).toBe(25)
    expect(square(0)).toBe(0)
  })

  it('isEven() returns true for even numbers, false for odd', () => {
    expect(isEven(4)).toBe(true)
    expect(isEven(7)).toBe(false)
  })

  it('parityLabel() returns "even" or "odd" using a ternary', () => {
    expect(parityLabel(4)).toBe('even')
    expect(parityLabel(7)).toBe('odd')
  })
})
