import { describe, it, expect } from 'vitest'
import { add, makeMultiplier } from '../src/functions.js'

describe('5. Functions', () => {
  it('add() is an arrow function that sums two numbers', () => {
    expect(add(2, 3)).toBe(5)
    expect(add(-1, 1)).toBe(0)
  })

  // Stretch: a closure - a function that returns another function.
  it('makeMultiplier() returns a closure that multiplies by its factor', () => {
    const triple = makeMultiplier(3)
    expect(triple(5)).toBe(15)
    expect(makeMultiplier(10)(4)).toBe(40)
  })
})
