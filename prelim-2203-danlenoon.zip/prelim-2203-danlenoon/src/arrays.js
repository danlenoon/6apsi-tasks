// Arrays. REFERENCE.md has a worked example of map, filter, and reduce.

// double([1,2,3])  ->  [2,4,6]
// Transform every item into a new array. Which array method transforms items?
export function double(nums) {
  return nums.map(x => x * 2);
}

// evens([1,2,3,4])  ->  [2,4]
// Keep only some of the items. Which array method keeps items that pass a test?
export function evens(nums) {
  return nums.filter(x => x % 2 === 0);
}

// names([{name:'Ana'},{name:'Ben'}])  ->  ['Ana','Ben']
// Transform each object into just one of its properties.
export function names(people) {
  return people.map(p => p.name);
}

// STRETCH. total([1,2,3])  ->  6    total([])  ->  0
// Combine all the numbers into a single value. REFERENCE.md shows the method
// that folds an array into one result; adapt its example to add them up.
export function total(nums) {
  return nums.reduce((acc, x) => acc + x, 0);
}