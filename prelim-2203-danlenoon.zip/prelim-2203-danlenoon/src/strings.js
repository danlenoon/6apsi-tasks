// Strings. REFERENCE.md lists the string methods you can reach for.

// firstLetter('hello')  ->  'h'
// The single character at the start of the string.
export function firstLetter(s) {
  return s.charAt(0);
}

// shout('hi')  ->  'HI!'
// Upper-case the whole string, then add an exclamation mark.
export function shout(s) {
  return `${s.toUpperCase()}!`;
}

// capitalize('hello')  ->  'Hello'
// Only the FIRST letter changes; the rest stays as-is. You'll join two pieces:
// the first character (upper-cased) and the remainder of the string.
export function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

// STRETCH. countVowels('hello')  ->  2    countVowels('AEIOU')  ->  5
// Count vowels, ignoring case. Think about looking at each character and
// deciding whether it is a vowel. REFERENCE.md shows a counting loop you can
// adapt (its example counts one specific letter; you want any vowel).
export function countVowels(s) {
  let count = 0;
  
  for (const ch of s.toLowerCase()) {
    if ('aeiou'.includes(ch)) count++;
  }
  
  return count;
}