// Objects. REFERENCE.md covers destructuring and spread.

// fullName({ firstName: 'Juan', lastName: 'Cruz' })  ->  'Juan Cruz'
// Read firstName and lastName out of the object (destructuring), then join them
// with a space.
export function fullName(person) {
  const { firstName, lastName } = person;
  return `${firstName} ${lastName}`;
}

// STRETCH. withUpdates({a:1,b:2}, {b:9})  ->  {a:1, b:9}
// Return a NEW object with obj's keys and updates applied on top (later keys
// win). Do NOT change the original object. The spread operator builds new
// objects from existing ones - see REFERENCE.md.
export function withUpdates(obj, updates) {
  return { ...obj, ...updates };
}