// Functions and closures. REFERENCE.md shows an arrow function and a closure.

// add(2, 3)  ->  5.  Write it as an arrow function.
export const add = (a, b) => {
  return a + b;
}

// STRETCH. makeMultiplier builds a function:
//   const triple = makeMultiplier(3);  triple(5)  ->  15
// This is a closure - the returned function remembers `factor`. REFERENCE.md
// shows makeAdder (which adds); adapt the same shape to multiply instead.
export function makeMultiplier(factor) {
  return function (n) {
    return n * factor;
  };
}