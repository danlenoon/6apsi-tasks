import Greeting from './Greeting.jsx'

// This renders your Greeting component so you can see it with `npm run dev`.
// You do not need to change this file; build the component in Greeting.jsx.
// The rest of the exam is plain JavaScript, checked by the tests only.
export default function App() {
  return (
    <main style={{ fontFamily: 'system-ui, sans-serif', padding: '2rem' }}>
      <Greeting name="Ana" />
    </main>
  )
}