// STRETCH (intro React). A component is a function that returns JSX; a prop is
// data passed in - here, `name` (already destructured for you).
//
//   <Greeting name="Ana" />   should render a level-1 heading reading:  Hello, Ana!
//
// REFERENCE.md shows a component that drops a prop into a heading with { }.
// Adapt it: use an <h1> and greet the name.
export default function Greeting({ name }) {
  return <h1>Hello, {name}!</h1>;
}