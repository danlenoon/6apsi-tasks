// Tier 1: warm-ups. If you forget a bit of syntax, check REFERENCE.md.

// greet('Ana')  ->  'Hello, Ana!'
// Build the string with a template literal (backticks and ${ }).
export function greet(name) {
  return `Hello, ${name}!`;
}

// square(5)  ->  25
export function square(n) {
  return n * n;
}

// isEven(4)  ->  true    isEven(7)  ->  false
// Whether a number divides evenly by 2. See "Modulo" in REFERENCE.md.
export function isEven(n) {
  return n % 2 === 0;
}

// parityLabel(4)  ->  'even'    parityLabel(7)  ->  'odd'
// Pick one of two strings based on a condition. A ternary fits (REFERENCE.md).
export function parityLabel(n) {
  return n % 2 === 0 ? 'even' : 'odd';
}