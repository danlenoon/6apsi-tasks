# Prelim Exam - JavaScript fundamentals + intro React

[![Made with Claude](https://img.shields.io/badge/Made_with-Claude-D97757?logo=anthropic&logoColor=white)](https://tjakoen.github.io/notes/ten-times-zero)
![Node.js](https://img.shields.io/badge/Node.js-5FA04E?logo=nodedotjs&logoColor=white)
![React](https://img.shields.io/badge/React-61DAFB?logo=react&logoColor=black)
![Vitest](https://img.shields.io/badge/Vitest-6E9F18?logo=vitest&logoColor=white)

A short, **closed-book** practical exam for the prelim period. It covers the
everyday JavaScript from Module 1 and one small React component from the start of
Module 2. You write real code; the tests score it.

> **Exam conditions:** proctored and closed-book. **No internet, no AI
> assistants, no notes** - the **only** reference you may use is the
> [`REFERENCE.md`](./REFERENCE.md) sheet in this repo, which shows each idea with
> a different example. You may run the tests as often as you like.

Each `src/` file opens with a worked `input -> output` example, and the stubs for
the harder tasks are partly filled in for you. **Read [`REFERENCE.md`](./REFERENCE.md)** -
it has the syntax you need for every task.

## Setup

1. Create your copy from this template into the **`HAU-6APSI`** org, set to
   **Private**, named `prelim-<classcode>-yourname`.
2. Open it in a **Codespace** (green *Code* button -> Codespaces), or clone it and
   run `npm install`.
3. Fill in **`student.json`** first.
4. Implement the functions in **`src/`** until the tests pass.
5. Run `npm test` (or `npm run test:watch`). **Push to submit.**

## What to write (the contract)

Work top to bottom - it goes from warm-ups to harder **stretch** tasks. Do the
easy ones first; you do not need every task to pass. Names and files must match.

| File | Function | Tier | Do |
| --- | --- | --- | --- |
| `src/basics.js` | `greet(name)` | warm-up | return `Hello, <name>!` (template literal) |
| | `square(n)` | warm-up | return `n * n` |
| | `isEven(n)` | warm-up | `true`/`false` (`n % 2`) |
| | `parityLabel(n)` | warm-up | `"even"` / `"odd"` (ternary) |
| `src/strings.js` | `firstLetter(s)` | warm-up | the first character |
| | `shout(s)` | warm-up | upper-case + `"!"` |
| | `capitalize(s)` | core | upper-case only the first letter |
| | `countVowels(s)` | **stretch** | count vowels, case-insensitively |
| `src/arrays.js` | `double(nums)` | core | each number doubled (`.map()`) |
| | `evens(nums)` | core | only the even numbers (`.filter()`) |
| | `names(people)` | core | map each object to its `.name` |
| | `total(nums)` | **stretch** | the sum (`.reduce()`) |
| `src/objects.js` | `fullName(person)` | core | destructure, return `"First Last"` |
| | `withUpdates(obj, updates)` | **stretch** | new merged object (spread), no mutation |
| `src/functions.js` | `add(a, b)` | core | arrow function returning the sum |
| | `makeMultiplier(factor)` | **stretch** | return a closure that multiplies by `factor` |
| `src/Greeting.jsx` | `Greeting` | **stretch** | component: render a level-1 heading reading `Hello, <name>!` |

## Grading

Worth **100 points**: **80** from the automated tests and **20** for code quality.
The tests are graded on how many pass, so partial work still scores - aim to clear
the warm-up and core tasks first, then reach for the stretch ones. The final
**80 -> 100** is the code-quality mark: clean, idiomatic code that genuinely solves
the problem. Hard-coding the sample inputs passes no test cleanly and earns no
quality marks.

---
📚 **These materials were authored by [tjakoen](https://github.com/tjakoen), built with Claude.** I use AI in the open, and I expect you to use it to learn the material, not to skip the learning. [How I actually work with AI →](https://tjakoen.github.io/notes/ten-times-zero)
