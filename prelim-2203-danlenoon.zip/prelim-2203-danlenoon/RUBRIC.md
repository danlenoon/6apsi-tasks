# Rubric - Prelim Exam (Module 1 JavaScript + intro React)

This is the **proctored, closed-book** prelim exam. A one-page reference sheet
(`REFERENCE.md`) is provided and allowed; no other docs, internet, or AI. It is
worth **100 points**: **80 automated** (the objective test suite, scored by the
grade sweep) and **20 for code quality, graded by the instructor by hand** from
the source. No AI grading is used on this exam.

## How the 100 points are shaped (deliberate)

Three bands, so everyone has a fair shot at passing while a perfect score stays
hard to reach:

1. **Foundational tasks (most of the 80).** Warm-ups and core string/array/object
   work. With the reference sheet these are within reach for any prepared
   student - this is the fair pass base.
2. **Stretch tasks (the top of the 80).** `countVowels`, `total` (reduce),
   `withUpdates` (spread, no mutation), `makeMultiplier` (closure), and the
   `Greeting` React component. Scaffolded, but they separate strong students.
3. **Code quality (the final 20, i.e. 80 -> 100).** The hard ceiling: idiomatic,
   clean, genuinely-understood code. Passing tests alone does not earn it.

## Automated checks (80 pts, from the test suite)

The objective score is the pass ratio of the prelim vitest suite scaled to 80
(each passing test is an equal share of 80, about 4.2 pts). The grade sweep
computes this and pushes it to Canvas; you then add the 20 code-quality points by
hand. Coverage:

| Area | Tasks | Tier | Weight |
| --- | --- | --- | --- |
| Basics (`basics`) | greet, square, isEven, parityLabel | foundational | 17 |
| Strings (`strings`) | firstLetter, shout, capitalize, **countVowels** | foundational + stretch | 17 |
| Arrays (`arrays`) | double, evens, names, **total (reduce)** | foundational + stretch | 17 |
| Objects (`objects`) | fullName, **withUpdates (spread)** | foundational + stretch | 8 |
| Functions (`functions`) | add, **makeMultiplier (closure)** | foundational + stretch | 8 |
| React (`greeting`) | **Greeting component** | stretch | 9 |
| Student info (`student`) | `student.json` filled correctly | foundational | 4 |
| **Automated subtotal** | | | **80** |

## Code quality (20 pts, graded by the instructor)

You score this table by hand from the student's source - this is the 80 -> 100
gate, so hold full marks for genuinely clean, idiomatic work. Keep the bar
beginner-appropriate but real.

| Criterion | Max | Excellent | Satisfactory (~60-80%) | Needs work (~0-40%) |
| --- | --- | --- | --- | --- |
| Idiomatic JavaScript | 7 | uses the right tool (arrow fns, map/filter/reduce, destructuring, spread) rather than long manual loops where a method fits; concise and correct | mostly idiomatic, some clunky spots | verbose or fights the language |
| Understanding, not test-gaming | 6 | solutions are general and correct, not hard-coded to the sample inputs | mostly general, a shortcut or two | pattern-matched to the tests |
| Readability and naming | 4 | clear names, consistent style, no dead code or leftover scaffold comments | readable but uneven | hard to follow |
| React component quality | 3 | a clean component that reads its prop and returns simple JSX | works but awkward | confused about props/JSX |

Code-quality total: 20 points.

**Automated 80 + code quality 20 = 100 total.**

The sweep sets `autoPoints: 80`, so `canvas-push` sends the objective 80 and lists
this exam under "add subjective points manually in Canvas" - that reminder is
where you enter the 20 you graded here.
