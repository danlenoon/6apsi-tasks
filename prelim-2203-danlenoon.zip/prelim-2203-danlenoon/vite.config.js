import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'

// The exam mixes plain-JS functions (src/*.js) and one small React component
// (src/Greeting.jsx). Vitest runs everything in jsdom so the React test can
// render, and the React plugin compiles the JSX. You do not need to change this.
export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: './test/setup.js',
  },
})
