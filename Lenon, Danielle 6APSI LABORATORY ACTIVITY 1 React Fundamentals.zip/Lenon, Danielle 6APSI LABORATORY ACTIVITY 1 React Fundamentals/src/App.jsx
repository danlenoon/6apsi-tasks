import React from 'react';
import ProfileCard from './ProfileCard';
import './App.css';

function App() {
  return (
    <div className="app-container">
      <header className="app-header">
        <h1>Developer Profile Dashboard</h1>
        <p>Connect with amazing developers from around the world.</p>
      </header>
      <main className="cards-container">
        <ProfileCard 
          name="Danielle Lenon"
          title="App Developer"
          bio="This person is quite ambitious about transforming imaginative app interfaces into functional realities for user experiences."
        />
        <ProfileCard 
          name="Johnny Turnus"
          title="High-Level Engineer"
          bio="This person is highly ambitious, taking software to the next level, unlike any competition before."
        />
        <ProfileCard 
          name="Creggy Fettuchini"
          title="Software Engineer"
          bio="This person is very ambitious in organizing and ensuring the best code and programming practices."
        />
      </main>
    </div>
  );
}

export default App;
