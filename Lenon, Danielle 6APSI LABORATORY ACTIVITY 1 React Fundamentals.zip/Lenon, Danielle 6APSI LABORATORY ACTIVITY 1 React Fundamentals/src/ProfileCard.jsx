import { useState } from 'react';
import './ProfileCard.css';

const ProfileCard = ({ name, title, bio }) => {
  const [connections, setConnections] = useState(0);

  const handleConnect = () => {
    setConnections(connections + 1);
  };

  return (
    <div className="profile-card">
      {connections >= 5 && (
        <div className="badge">🌟 Popular Developer</div>
      )}
      <h1>{name}</h1>
      <h2>{title}</h2>
      <p>{bio}</p>
      
      <div className="card-actions">
        <button onClick={handleConnect} className={connections > 0 ? 'connected' : ''}>
          {connections > 0 ? "Send Message" : "Connect"}
        </button>
        <span className="connections-count">
          {connections} connection{connections !== 1 ? 's' : ''}
        </span>
      </div>
    </div>
  );
};

export default ProfileCard;
