// Data access for the sightings table.
//
// The new idea here is the JOIN. A sighting row only stores investigator_id - a
// number. That is useless to whoever calls the API, so every READ in this file
// must return the reporter's name alongside the sighting, in a column named
// exactly:
//
//   investigator_name
//
// Research: JOIN ... ON, and column aliases (SELECT i.name AS investigator_name).
// One SELECT with a JOIN can serve all three reads below - write it once and
// reuse it rather than repeating yourself.
//
// Parameterized queries only, same as always.

const SIGHTING_WITH_INVESTIGATOR_SELECT = `
  SELECT 
    s.id,
    s.investigator_id,
    s.place,
    s.description,
    s.spookiness,
    i.name AS investigator_name
  FROM sightings s
  JOIN investigators i ON s.investigator_id = i.id
`

export async function create(pool, { investigator_id, place, description, spookiness }) {
  const result = await pool.query(
    `INSERT INTO sightings (investigator_id, place, description, spookiness)
     VALUES ($1, $2, $3, $4)
     RETURNING id`,
    [investigator_id, place, description ?? null, spookiness]
  )
  return getById(pool, result.rows[0].id)
}

export async function getAll(pool, { minSpookiness } = {}) {
  if (minSpookiness !== undefined && minSpookiness !== null) {
    const result = await pool.query(
      `${SIGHTING_WITH_INVESTIGATOR_SELECT}
       WHERE s.spookiness >= $1
       ORDER BY s.id`,
      [minSpookiness]
    )
    return result.rows
  }
  const result = await pool.query(
    `${SIGHTING_WITH_INVESTIGATOR_SELECT}
     ORDER BY s.id`
  )
  return result.rows
}

export async function getById(pool, id) {
  const result = await pool.query(
    `${SIGHTING_WITH_INVESTIGATOR_SELECT}
     WHERE s.id = $1`,
    [id]
  )
  return result.rows[0] || null
}

export async function getByInvestigator(pool, investigatorId) {
  const result = await pool.query(
    `${SIGHTING_WITH_INVESTIGATOR_SELECT}
     WHERE s.investigator_id = $1
     ORDER BY s.id`,
    [investigatorId]
  )
  return result.rows
}

export async function update(pool, id, { place, description, spookiness }) {
  const existing = await getById(pool, id)
  if (!existing) {
    return null
  }

  const newPlace = place !== undefined ? place : existing.place
  const newDesc = description !== undefined ? description : existing.description
  const newSpookiness = spookiness !== undefined ? spookiness : existing.spookiness

  await pool.query(
    `UPDATE sightings
     SET place = $1, description = $2, spookiness = $3
     WHERE id = $4`,
    [newPlace, newDesc, newSpookiness, id]
  )

  return getById(pool, id)
}

export async function remove(pool, id) {
  const result = await pool.query(
    'DELETE FROM sightings WHERE id = $1',
    [id]
  )
  return result.rowCount > 0
}
