// Module 5 - Activity 4 - the HTTP layer.
//
// This is the finish line for the midterm: Module 4 (Express, routing,
// middleware, REST design) on top of Module 5 (Postgres, relations, SQL).
//
// THE RULE THAT IS BEING GRADED: routes speak HTTP, repos speak SQL.
// There must be NO SQL in this file, and no req/res in the repo files.
//
// Build createApp(pool) and RETURN the app.

import express from 'express'
import * as investigators from './investigatorsRepo.js'
import * as sightings from './sightingsRepo.js'

// --- middleware -------------------------------------------------------------

function isValidInvestigator(body) {
  if (!body || typeof body !== 'object') return false
  const hasName = typeof body.name === 'string' && body.name.trim().length > 0
  const hasEmail = typeof body.email === 'string' && body.email.includes('@')
  return hasName && hasEmail
}

function isValidSighting(body) {
  if (!body || typeof body !== 'object') return false
  const validInvId = typeof body.investigator_id === 'number' && Number.isInteger(body.investigator_id) && body.investigator_id > 0
  const validPlace = typeof body.place === 'string' && body.place.trim().length > 0
  const validSpookiness = typeof body.spookiness === 'number' && Number.isInteger(body.spookiness) && body.spookiness >= 1 && body.spookiness <= 5
  return validInvId && validPlace && validSpookiness
}

export function createApp(pool) {
  const app = express()
  app.use(express.json())

  app.param('id', (req, res, next, id) => {
    if (!/^\d+$/.test(id)) {
      return res.status(400).json({ error: 'Invalid ID' })
    }
    next()
  })

  // GET /health -> 200 with { status: 'ok' }.
  app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok' })
  })

  // --- investigators --------------------------------------------------------

  // GET /investigators -> 200 with every investigator.
  app.get('/investigators', async (req, res) => {
    const list = await investigators.getAll(pool)
    res.status(200).json(list)
  })

  // POST /investigators
  app.post('/investigators', async (req, res) => {
    if (!isValidInvestigator(req.body)) {
      return res.status(400).json({ error: 'Invalid investigator data' })
    }
    const existing = await investigators.getByEmail(pool, req.body.email)
    if (existing) {
      return res.status(409).json({ error: 'Email already registered' })
    }
    const created = await investigators.create(pool, req.body)
    res.status(201).json(created)
  })

  // GET /investigators/:id/sightings
  app.get('/investigators/:id/sightings', async (req, res) => {
    const inv = await investigators.getById(pool, req.params.id)
    if (!inv) {
      return res.status(404).json({ error: 'Investigator not found' })
    }
    const list = await sightings.getByInvestigator(pool, req.params.id)
    res.status(200).json(list)
  })

  // --- sightings ------------------------------------------------------------

  // GET /sightings -> 200 with every sighting.
  app.get('/sightings', async (req, res) => {
    if (req.query.minSpookiness !== undefined) {
      const minSpookiness = Number(req.query.minSpookiness)
      if (!/^-?\d+$/.test(req.query.minSpookiness) || isNaN(minSpookiness)) {
        return res.status(400).json({ error: 'minSpookiness must be a number' })
      }
      const list = await sightings.getAll(pool, { minSpookiness })
      return res.status(200).json(list)
    }
    const list = await sightings.getAll(pool)
    res.status(200).json(list)
  })

  // GET /sightings/:id -> 200 with the sighting, or 404.
  app.get('/sightings/:id', async (req, res) => {
    const row = await sightings.getById(pool, req.params.id)
    if (!row) {
      return res.status(404).json({ error: 'Sighting not found' })
    }
    res.status(200).json(row)
  })

  // POST /sightings
  app.post('/sightings', async (req, res) => {
    if (!isValidSighting(req.body)) {
      return res.status(400).json({ error: 'Invalid sighting data' })
    }
    const inv = await investigators.getById(pool, req.body.investigator_id)
    if (!inv) {
      return res.status(400).json({ error: 'Investigator does not exist' })
    }
    const created = await sightings.create(pool, req.body)
    res.status(201).json(created)
  })

  // PATCH /sightings/:id
  app.patch('/sightings/:id', async (req, res) => {
    const existing = await sightings.getById(pool, req.params.id)
    if (!existing) {
      return res.status(404).json({ error: 'Sighting not found' })
    }
    const updated = await sightings.update(pool, req.params.id, req.body)
    res.status(200).json(updated)
  })

  // DELETE /sightings/:id
  app.delete('/sightings/:id', async (req, res) => {
    const deleted = await sightings.remove(pool, req.params.id)
    if (!deleted) {
      return res.status(404).json({ error: 'Sighting not found' })
    }
    res.sendStatus(204)
  })

  // 404 fallback for anything unmatched.
  app.use((req, res) => res.status(404).json({ error: 'Not found' }))

  // Error-handling middleware (four arguments)
  app.use((err, req, res, next) => {
    const status = err.status || err.statusCode || 400
    res.status(status).json({ error: err.message || 'Bad Request' })
  })

  return app
}
