// Data access for the investigators table.
//
// This is the SQL half of the app, and it is yours to write this time (in m5a3 it
// was handed to you). No req, no res, no status codes in this file - it takes
// plain values and returns plain rows.
//
// Every query must be PARAMETERIZED ($1, $2, ...). Never build a query by gluing
// strings together; look up "SQL injection" if you want to know why.

export async function create(pool, { name, email }) {
  const result = await pool.query(
    'INSERT INTO investigators (name, email) VALUES ($1, $2) RETURNING *',
    [name, email]
  )
  return result.rows[0]
}

export async function getAll(pool) {
  const result = await pool.query(
    'SELECT * FROM investigators ORDER BY id'
  )
  return result.rows
}

export async function getById(pool, id) {
  const result = await pool.query(
    'SELECT * FROM investigators WHERE id = $1',
    [id]
  )
  return result.rows[0] || null
}

export async function getByEmail(pool, email) {
  const result = await pool.query(
    'SELECT * FROM investigators WHERE email = $1',
    [email]
  )
  return result.rows[0] || null
}
