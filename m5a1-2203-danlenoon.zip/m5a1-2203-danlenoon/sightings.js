// Module 5 - Activity 1 - SQL and connecting to PostgreSQL
//
// Give the HAUnted Sightings app a real table. You will write three functions
// that take a connected `pg` client and run SQL against it. The tests hand you an
// in-memory Postgres, and the same code works against a real one (see db.js).
//
// GOLDEN RULE: never build SQL by gluing strings together. Any value goes in as a
// parameter ($1, $2, ...) with a separate values array. Read db-theory/03 (the
// "parameterized queries" section) before you write a single query.

export async function createSchema(client) {
  await client.query(`
    CREATE TABLE IF NOT EXISTS sightings (
      id          SERIAL PRIMARY KEY,
      place       TEXT NOT NULL,
      description TEXT,
      spookiness  INTEGER NOT NULL,
      reported_at TIMESTAMPTZ DEFAULT now()
    )
  `)
}

export async function insertSighting(client, { place, description, spookiness }) {
  const res = await client.query(
    `INSERT INTO sightings (place, description, spookiness) VALUES ($1, $2, $3) RETURNING *`,
    [place, description, spookiness]
  )
  return res.rows[0]
}

export async function getSighting(client, id) {
  const res = await client.query(
    `SELECT * FROM sightings WHERE id = $1`,
    [id]
  )
  return res.rows[0] ?? null
}

